﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace goncamarket
{
    public partial class frmKatagori : Form
    {
        public frmKatagori()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-0OVN98A;Initial Catalog=gonca_market;Integrated Security=True");
        bool durum;
        private void kategorikontrol()
        {
            durum= true;
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select *from kategoribilgi",baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                if (textBox1.Text == read["kategori"].ToString() || textBox1.Text == "")
                {
                    durum = false;
                }
            }
            baglanti.Close();
        }
        private void frmKatagori_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            kategorikontrol();
            if (durum == true)
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("insert into kategoribilgi(kategori) values ('" + textBox1.Text + "')", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                
                MessageBox.Show("kategori eklenmiştir");
            }
            else
            {
                MessageBox.Show("kategori vardır","hata");
            }
            textBox1.Text = "";


        }
    }
}
