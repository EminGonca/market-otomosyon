﻿namespace goncamarket
{
    internal class Formsatış
    {
        internal static Image indir__1_;
    }
}